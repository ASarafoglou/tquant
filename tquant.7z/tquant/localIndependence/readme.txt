Local independence (BLIM).

