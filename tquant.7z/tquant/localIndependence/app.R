# setwd("C:/Users/Dini/Documents/Programmieren/tquant/localIndependence")
# library("shiny")
# runApp("app.R")

ui <- fluidPage()			# create web page
server <- function(input, output){}	# calculate output
					# from user input

#==========================ui==========================
#======Ratewk und Leichtsinnsfehler=======
ui <- fluidPage(
 h3("PKS"),
 verticalLayout(
# Lucky guess	       	       
   h4(strong("Which parameter describes the following expressions?"), "Select
      the right parameter."),
   h5(
     column(4, 
       strong("Lucky guess"), br(),
         HTML("<select id='RW'>Lucky guess</option>
           <option value='so'>Select one</option>
           <option value='beta'>&#946;</option>
           <option value='Nbeta'>1 - &#946;</option>
	   <option value='eta'>&#951;</option>
	   <option value='Neta'>1 - &#951;</option>
           </select>"
	 ),
         uiOutput("RW"), 
      # Careless Error
         strong("Careless Error"),
	 br(),	
  	 HTML("<select id='LF'>Careless Error</option>
           <option value='so'>Select one</option>
           <option value='beta'>&#946;</option>
           <option value='Nbeta'>1 - &#946;</option>
	   <option value='eta'>&#951;</option>
	   <option value='Neta'>1 - &#951;</option>
           </select>"
	 ),
         uiOutput("LF")
     ),
	     
     column(6,
       strong("Correct! (know it)"), br(),
         HTML("<select id='R'>Correct! (know it)</option>
           <option value='so'>Select one</option>
           <option value='beta'>&#946;</option>
           <option value='Nbeta'>1 - &#946;</option>
	   <option value='eta'>&#951;</option>
	   <option value='Neta'>1 - &#951;</option>
           </select>"
	 ),
	 uiOutput("R"),
	 
       strong("Wrong! (don't know it)"), br(),
	 HTML("<select id='F'>Wrong! (don't know it)</option>
           <option value='so'>Select one</option>
           <option value='beta'>&#946;</option>
           <option value='Nbeta'>1 - &#946;</option>
	   <option value='eta'>&#951;</option>
	   <option value='Neta'>1 - &#951;</option>
           </select>"
	 ),
	 uiOutput("F")
     )
   ),


#==========d(R\K)
   h5(hr(),
      h4(strong("Sarah takes part in a test with five items (a, b, c, d, e).
		She only masters item a and b. But she answers
		item b, c, and e correctly."), 
	strong("The response pattern R contains Sarah's correct
	       responses, the knowledge state K contains the items
	       she masters."),
	br(),
	"Select in which of the sets below each item should be placed"),
     column(6, plotOutput("Venn"), br()),
     column(3, " ", uiOutput("Mengen")),
     column(3,
       strong("Item a is element of"), br(),
         HTML("<select id='A'>Item a</option>
           <option value='so'>Select one</option>
           <option value='k'>K \\ R</option>
           <option value='r'>R \\ K</option>
	   <option value='kr'>R &#8745; K</option>
	   <option value='nkr'>&#172; R &#8745; &#172; K</option>
           </select>"
	 ),
       uiOutput("Itema"),     
       strong("Item b is element of"), br(),
         HTML("<select id='B'>Item b is element of</option>
           <option value='so'>Select one</option>
           <option value='k'>K \\ R</option>
           <option value='r'>R \\ K</option>
	   <option value='kr'>R &#8745; K</option>
	   <option value='nkr'>&#172; R &#8745; &#172; K</option>
           </select>"
	 ),
       uiOutput("Itemb"), 
       strong("Item c is element of"), br(),
         HTML("<select id='C'>Item c</option>
           <option value='so'>Select one</option>
           <option value='k'>K \\ R</option>
           <option value='r'>R \\ K</option>
	   <option value='kr'>R &#8745; K</option>
	   <option value='nkr'>&#172; R &#8745; &#172; K</option>
           </select>"
	 ),
       uiOutput("Itemc"), 
       strong("Item d is element of"), br(),
         HTML("<select id='D'>Item d</option>
           <option value='so'>Select one</option>
           <option value='k'>K \\ R</option>
           <option value='r'>R \\ K</option>
	   <option value='kr'>R &#8745; K</option>
	   <option value='nkr'>&#172; R &#8745; &#172; K</option>
           </select>"
	 ),
       uiOutput("Itemd"), 
       strong("Item e is element of"), br(),
         HTML("<select id='E'>Item e</option>
           <option value='so'>Select one</option>
           <option value='k'>K \\ R</option>
           <option value='r'>R \\ K</option>
	   <option value='kr'>R &#8745; K</option>
	   <option value='nkr'>&#172; R &#8745; &#172; K</option>
           </select>"
	 ),
       uiOutput("Iteme") 
      	      
     )
   ),
#==========P(R|K)
   h5(hr(),
       h4(strong("Now classify Sarah's answers to each item."), br(),
	  "If your answer is correct, the parameter will appear in the formula below. If your answer is wrong, a questionmark will appear instead."),
      br(),
     column(2, radioButtons("a", "Item a", 
       c("Correct! (know it)" = 'r',
         "Lucky guess!" = 'RW',
         "Careless error!" = 'LF', 
         "Wrong! (don't know it)" = 'f') 
       ),
     actionButton("aa", "Submit"), br(),
     uiOutput("Formel1")
     ),

     column(2, radioButtons("b", "Item b", 
       c("Correct! (know it)" = 'r',
	 "Lucky guess!" = 'RW',
	 "Careless error!" = 'LF', 
         "Wrong! (don't know it)" = 'f')
       ),
     actionButton("ab", "Submit"), br(),
     uiOutput("Formel2")
     ),

     column(2, radioButtons("c", "Item c", 
       c("Correct! (know it)" = 'r',
         "Lucky guess!" = 'RW',
	 "Careless error!" = 'LF', 
         "Wrong! (don't know it)" = 'f')
       ),
       actionButton("ac", "Submit"), br(),
       uiOutput("Formel3")
     ),
		
     column(2, radioButtons("d", "Item d", 
       c("Correct! (know it)" = 'r',
         "Lucky guess!" = 'RW',
         "Careless error!" = 'LF', 
         "Wrong! (don't know it)" = 'f')
        ),
       	actionButton("ad", "Submit"), br(),
	uiOutput("Formel4")
      ),


      column(2,radioButtons("e", "Item e", 
        c("Correct! (know it)" = 'r',
          "Lucky guess!" = 'RW',
	  "Careless error!" = 'LF', 
          "Wrong! (don't know it)" = 'f')
        ),
       	actionButton("ae", "Submit"), br(),
        uiOutput("Formel5")
     )
   ),

#======================= unterste Formel
   h6(
      h4(strong("The probability of the response pattern R given the knowledge 
      state K is:"), br(), "R = {b,c,e} and K = {a,b}") ,		
#column(6, textOutput("Formela")),
#column(6, textOutput("Formelb"))

     column(1, h4(HTML("P(R|K) = "))),
     column(1, uiOutput("Formela")),
     column(1, h4(HTML("<strong>&sdot;</strong>"))),
     column(1, uiOutput("Formelb")),
     column(1, h4(HTML("<strong>&sdot;</strong>"))),
     column(1, uiOutput("Formelc")),
     column(1, h4(HTML("<strong>&sdot;</strong>"))),
     column(1, uiOutput("Formeld")),
     column(1, h4(HTML("<strong>&sdot;</strong>"))),
     column(1, uiOutput("Formele")), br(), br()
   ),
   h4(br(), strong("Select probabilities and see how P(R|K) changes!")),	
   h5(column(5,
       sliderInput("sa", HTML("Select a probability for &#946;<sub>a</sub>"), 
		 min = 0, max = 0.49, step = 0.01, value = 0.1),
       sliderInput("sc",  HTML("Select a probability for &#951;<sub>c</sub>"), 
		  min = 0, max = 0.49, step = 0.01, value = 0.25),
       sliderInput("se",  HTML("Select a probability for &#951;<sub>e</sub>"), 
		  min = 0, max = 0.49, step = 0.01, value = 0.45)     
     ),
     column(1,paste("")),
     column(6,
       sliderInput("sb", HTML("Select a probability for  &#946;<sub>b</sub>"), 
		  min = 0, max = 0.49, step = 0.01, value = 0.15), #
       sliderInput("sd",  HTML("Select a probability for &#951;<sub>d</sub>"), 
		  min = 0, max = 0.49, step = 0.01, value = 0.35),
       h4(strong("The probability of the response pattern R given the
	    knowledge state K is: ")),
       h4(textOutput("Ergebnis"), br(), br())
     )    
   )
 )
)
#=========================server================================
server <- function(input, output){

  output$RW <- renderText({
    if(input$RW == "eta"){
      HTML("<h5 style='color:green' align='left'>  Well done! ")}
    else if(input$RW == 'so'){HTML("<br>")}
    else{HTML("<h5 style ='color:red' align='left'> Wrong! Try again!")}	
  })	

  output$LF <- renderText({
    if(input$LF == "beta"){
      HTML("<h5 style='color:green' align='left'>  Well done! ")}
    else if(input$LF == 'so'){HTML("<br>")}
    else{HTML("<h5 style ='color:red' align='left'> Wrong! Try again!")}	
  })

  output$R<- renderText({
    if(input$R == "Nbeta"){
      HTML("<h5 style='color:green' align='left'>  Well done! ")}
    else if(input$R == 'so'){HTML("<br>")}
    else{HTML("<h5 style ='color:red' align='left'> Wrong! Try again!")}	
  })

  output$F <- renderText({
    if(input$F == "Neta"){
      HTML("<h5 style='color:green' align='left'>  Well done! ")}
    else if(input$F == 'so'){HTML("<br>")}
    else{HTML("<h5 style ='color:red' align='left'> Wrong! Try again!")}	
  })

#=============================Action Button unten
  observeEvent(input$aa, {
    output$Formel1 <- renderUI({
      isolate(
        Fa <- if(input$a == "LF"){HTML(
		"<h5 style='color:green' align='left'>  Great! ")}
	else{HTML(
		"<h5 style ='color:red' align='left'> Wrong! ")}
      )
    })
  })

  observeEvent(input$ab, {
    output$Formel2 <- renderText({
      isolate(
	Fb <- if(input$b == "r"){HTML(
		"<h5 style='color:green' align='left'>  Great! ")}
	else{HTML(
		"<h5 style ='color:red' align='left'> Wrong! ")}
      )
    })
  })

  observeEvent(input$ac, {
    output$Formel3 <- renderText({
      isolate(
	Fc <- 	if(input$c == "RW"){HTML(
		"<h5 style='color:green' align='left'>  Great! ")}
	else{HTML(
		"<h5 style ='color:red' align='left'> Wrong! ")}
      )
    })
  })

  observeEvent(input$ad, {
    output$Formel4 <- renderText({
      isolate(
	Fd <- if(input$d == "f"){HTML(
		"<h5 style='color:green' align='left'>  Great! ")}
	else{HTML(
		"<h5 style ='color:red' align='left'> Wrong! ")}
      )
    })
  })

  observeEvent(input$ae, {
    output$Formel5 <- renderText({
      isolate(
	Fe <- if(input$e == "RW"){HTML(
		"<h5 style='color:green' align='left'>  Great! ")}
	else{HTML(
		"<h5 style ='color:red' align='left'> Wrong! ")}
      )
    })
  })
#====================================== Unterste Formel

  observeEvent(input$aa, {				       
    output$Formela <- renderText({
      isolate(
	Fa <- if(input$a == "LF"){
	  HTML("<h4 style='color:green' align='left'>&#946;<sub>a</sub>")}
	else{HTML("<h4 style='color:red' align='left'> ? ")}
      )
    })
  })


  observeEvent(input$ab, {				       
    output$Formelb <- renderText({
      isolate(
	Fb <- if(input$b == "r"){
	  HTML("<h4 style='color:green' align='left'>1 - &#946;<sub>b</sub>")}
	else{HTML("<h4 style='color:red' align='left'> ? ")}
      )
    })
  })

  observeEvent(input$ac, {				       
    output$Formelc <- renderText({
      isolate(
	Fc <- if(input$c == "RW"){
	  HTML("<h4 style='color:green' align='left'>&#951;<sub>c</sub>")}
	else{HTML("<h4 style='color:red' align='left'> ? ")}
      )
    })
  })

  observeEvent(input$ad, {				       
    output$Formeld <- renderText({
      isolate(
	Fd <- if(input$d == "f"){
	  HTML("<h4 style='color:green' align='left'>1 - &#951;<sub>d</sub>")}
	else{HTML("<h4 style='color:red' align='left'> ? ")}
      )
    })
  })

  observeEvent(input$ae, {				       
    output$Formele <- renderText({
      isolate(
	Fe <- if(input$e == "RW"){
	  HTML("<h4 style='color:green' align='left'>&#951;<sub>e</sub>")}
	else{HTML("<h4 style='color:red' align='left'> ? ")}
      )
    })
  })


#==================Venn Diagramm
  output$Venn <- renderPlot({
    par(pty="s", mai = c(0,0,0,0))
    plot(10, 10, type="n", axes=FALSE, xlab="", ylab="", xlim=c(7.9, 13), 
	 ylim=c(8.5,11.75))
    symbols(c(9.5, 11.5), c(10, 10), circles=c(1.7, 1.7), add=TRUE,
            inches=FALSE, fg=c("orange", "blue"), lwd = 3)
    text(x = 8.2, y = 11, labels = "R", col = "orange", cex = 1.5)
    text(x = 12.8, y = 11, labels = "K", col = "blue", cex = 1.5)
    if(input$A == "r"){
      text(x = 9.1, y = 10.8, labels = "a", col = "red", cex = 1.5)
    }else if(input$A == "k"){
      text(x = 11.9, y = 10.8, labels = "a", col = "darkgreen", cex = 1.5)
    }else if(input$A == "kr"){
      text(x = 10.5, y = 10.6, labels = "a", col = "red", cex = 1.5)
    }else if(input$A == "nkr"){
      text(x = 10.9, y = 11.2, labels = "a", col = "red", cex = 1.5)
    }else{}	

    if(input$B == "r"){
      text(x = 8.9, y = 10.4, labels = "b", col = "red", cex = 1.5)
    }else if(input$B == "k"){
      text(x = 12.2, y = 10.4, labels = "b", col = "red", cex = 1.5)
    }else if(input$B == "kr"){
      text(x = 10.3, y = 10.4, labels = "b", col = "darkgreen", cex = 1.5)
    }else if(input$B == "nkr"){
      text(x = 10.7, y = 11.3, labels = "b", col = "red", cex = 1.5)
    }else{}

    if(input$C == "r"){
      text(x = 9, y = 10, labels = "c", col = "darkgreen", cex = 1.5)
    }else if(input$C == "k"){
      text(x = 12.1, y = 10, labels = "c", col = "red", cex = 1.5)
    }else if(input$C == "kr"){
      text(x = 10.4, y = 10, labels = "c", col = "red", cex = 1.5)
    }else if(input$C == "nkr"){
      text(x = 10.5, y = 11.1, labels = "c", col = "red", cex = 1.5)
    }else{}

    if(input$D == "r"){
      text(x = 9, y = 9.6, labels = "d", col = "red", cex = 1.5)
    }else if(input$D == "k"){
      text(x = 12, y = 9.6, labels = "d", col = "red", cex = 1.5)
    }else if(input$D == "kr"){
      text(x = 10.5, y = 9.6, labels = "d", col = "red", cex = 1.5)
    }else if(input$D == "nkr"){
      text(x = 10.3, y = 11.2, labels = "d", col = "darkgreen", cex = 1.5)
    }else{}

    if(input$E == "r"){
      text(x = 9.3, y = 9.2, labels = "e", col = "darkgreen", cex = 1.5)
    }else if(input$E == "k"){
      text(x = 11.7, y = 9.2, labels = "e", col = "red", cex = 1.5)
    }else if(input$E == "kr"){
      text(x = 10.6, y = 9.3, labels = "e", col = "red", cex = 1.5)
    }else if(input$E == "nkr"){
      text(x = 10.1, y = 11.2, labels = "e", col = "red", cex = 1.5)
    }else{}
  })

  output$Itema <- renderText({
    if(input$A == "k"){
      HTML("<h5 style='color:green' align='left'>  Good! ")
    }else if(input$A == "so"){
      HTML("<br>")
    }else{HTML("<h5 style ='color:red' align='left'> False!")}
  })

   output$Itemb <- renderText({
    if(input$B == "kr"){
      HTML("<h5 style='color:green' align='left'>  Good! ")
    }else if(input$B == "so"){
      HTML("<br>")
    }else{HTML("<h5 style ='color:red' align='left'> False!")}
  })

   output$Itemc <- renderText({
    if(input$C == "r"){
      HTML("<h5 style='color:green' align='left'>  Good! ")
    }else if(input$C == "so"){
      HTML("<br>")
    }else{HTML("<h5 style ='color:red' align='left'> False!")}
  })

   output$Itemd <- renderText({
    if(input$D == "nkr"){
      HTML("<h5 style='color:green' align='left'>  Good! ")
    }else if(input$D == "so"){
      HTML("<br>")
    }else{HTML("<h5 style ='color:red' align='left'> False!")}
  })

 output$Iteme <- renderText({
    if(input$E == "r"){
      HTML("<h5 style='color:green' align='left'>  Good! ")
    }else if(input$E == "so"){
      HTML("<br>")
    }else{HTML("<h5 style ='color:red' align='left'> False!")}
  })

 output$Ergebnis <- renderText({
    X <- input$sa*(1-input$sb)*input$sc*(1-input$sd)*input$se
    paste("P(R|K) = ", round(X, digits = 4) )
    })

#========================Mengen
 output$Mengen <- renderUI({  
   MeR1 <- MeR2 <- MeR3 <- MeR4 <- MeR5 <- ""
   MeK1 <- MeK2 <- MeK3 <- MeK4 <- MeK5 <- ""
   if(input$A == "k"){
      MeK1 <- HTML("<h5 style='color:green' align='left'>  a ")
   }else if(input$A == "kr"){
      MeK1 <- HTML("<h5 style='color:green' align='left'>  a ")
      MeR1 <- HTML("<h5 style='color:red' align='left'>  a ")
   }else if(input$A == "r"){
      MeR1 <- HTML("<h5 style='color:red' align='left'>  a ")
   }else{}
   if(input$B == "k"){
     MeK2 <- HTML("<h5 style='color:green' align='left'> , b ") 
   }else if(input$B == "kr"){
     MeK2 <- HTML("<h5 style='color:green' align='left'> , b ") 
     MeR2 <- HTML("<h5 style='color:green' align='left'> b ")
   }else if(input$B == "r"){
     MeR2 <- HTML("<h5 style='color:green' align='left'> b ")
   }else{}
   if(input$C == "k"){
     MeK3 <- HTML("<h5 style='color:red' align='left'> , c ") 
   }else if(input$C == "kr"){
     MeK3 <- HTML("<h5 style='color:red' align='left'> , c ") 
     MeR3 <- HTML("<h5 style='color:green' align='left'> , c ")
   }else if(input$C == "r"){
     MeR3 <- HTML("<h5 style='color:green' align='left'> , c ")
   }else{}
   if(input$D == "k"){
     MeK4 <- HTML("<h5 style='color:red' align='left'> , d ") 
   }else if(input$D == "kr"){
     MeK4 <- HTML("<h5 style='color:red' align='left'> , d ") 
     MeR4 <- HTML("<h5 style='color:red' align='left'> , d ")
   }else if(input$D == "r"){
     MeR4 <- HTML("<h5 style='color:red' align='left'> , d ")
   }else{}
   if(input$E == "k"){
     MeK5 <- HTML("<h5 style='color:red' align='left'> , e ") 
   }else if(input$E == "kr"){
     MeK5 <- HTML("<h5 style='color:red' align='left'> , e ") 
     MeR5 <- HTML("<h5 style='color:green' align='left'> , e ")
   }else if(input$E == "r"){
     MeR5 <- HTML("<h5 style='color:green' align='left'> , e ")
   }else{}

   h5(HTML("K = {", MeK1, MeK2, MeK3, MeK4, MeK5), 
      HTML("<h5 style='color:black' align='left'> }"), br(), 
      HTML("R = {", MeR1, MeR2, MeR3, MeR4, MeR5),
      HTML("<h5 style='color:black' align='left'> }"))


#<div class="Row">
#    <div class="Column">C1</div>
#    <div class="Column">C2</div>
#    <div class="Column">C3</div>
#</div>


})
     
     

}

shinyApp(ui = ui, server = server)
