Apps for TquanT project.

