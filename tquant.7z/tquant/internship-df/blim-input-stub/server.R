library(shiny)
library(pks)

data("DoignonFalmagne7")

shinyServer(function(input, output, session){
  
})







