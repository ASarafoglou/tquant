Apps from lecture "Statistik I."

