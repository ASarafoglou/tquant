App from Lisbon (2016) by AS et al.

