# blim(K, N.R, method = c("MD", "ML", "MDML"), R = as.binmat(N.R),
#      P.K = rep(1/nstates, nstates),
#      beta = rep(0.1, nitems), eta = rep(0.1, nitems),
#      betafix = rep(NA, nitems), etafix = rep(NA, nitems),
#      betaequal = NULL, etaequal = NULL,
#      errtype = c("both", "error", "guessing"),
#      errequal = FALSE, randinit = FALSE, incradius = 0,
#      tol = 1e-07, maxiter = 10000, zeropad = 12)

# load packages
library(pks)
library(R2jags)

# general settings 
 # N.R <- rep(10, 7)
 # names(N.R) <- as.pattern(K)
  
## Classical parameter estimation
frequentistParameterEstimation <- function(N.R, estimation.method, beta.parameters = rep(0.1, 4),
                                           eta.parameters  = rep(0.1, 4)){
  # estimates the frequentist model for blim
  
  K           <- as.binmat(c("0000", "0110", "0101", "1110", "1011", "1101", "1111")) 
  rownames(K) <- as.pattern(K)
  names(N.R)  <- as.pattern(K)
  classic.blim <- blim(K, N.R, method = estimation.method, beta = beta.parameters,
                       eta = eta.parameters)
}


## Bayesian parameter estimation
bayesianParameterEstimation <- function(N.R){
  # estimates the bayesian graphical model for blim
  
  # general settings
  K           <- as.binmat(c("0000", "0110", "0101", "1110", "1011", "1101", "1111")) 
  rownames(K) <- as.pattern(K)
  nitems  <- ncol(K)
  nstates <- nrow(K)
  names(N.R) <- as.pattern(K)
  R       <- as.binmat(N.R)
  npatterns <- 7
  n.observ  <- sum(N.R)
  # set up Bayesian graphical model
  data    <- list("N.R", "n.observ", "R", "K", "nitems", "nstates", "npatterns")
  myinits <- list(list(beta = rep(0.1, nitems), eta = rep(0.1, nitems), 
                       P.K = rep(1/nstates, nstates)),
                  list(beta = rep(0.1, nitems), eta = rep(0.1, nitems), 
                       P.K = rep(1/nstates, nstates)))
  parameters <- c("P.K", "eta", "beta")
  samples    <- jags(data, inits = myinits, parameters,
                     model.file  = "blim_model.txt", n.chains = 2, n.iter = 50000,
                     n.thin = 2, n.burnin=5000)
  return(samples)
}

## convergence diagnostics
convergenceDiagnostics <- function(samples, item.number){
  # calculates for each item Gelmans R for beta and eta parameter
  
  item.name.beta <- paste0("beta[", item.number, "]")
  item.name.eta  <- paste0("eta[", item.number, "]")
  # transform samples into mcmc list
  beta.list <- list(mcmc(samples$BUGSoutput$sims.array[, 1, item.name.beta]), # chain 1
                    mcmc(samples$BUGSoutput$sims.array[, 2, item.name.beta])) # chain 2
                         
  eta.list  <- list(mcmc(samples$BUGSoutput$sims.array[, 1, item.name.beta]), # chain 1
                    mcmc(samples$BUGSoutput$sims.array[, 2, item.name.beta])) # chain 2
  # compute gelmans R
  gelman.point.estimate <- gelman.diag(beta.list)$psrf[1]   
  gelman.upper.ci       <- gelman.diag(beta.list)$psrf[2]
  return(list(gelman.point.estimate = gelman.point.estimate,
              gelman.upper.ci       = gelman.upper.ci))
}

# ## Customize beta and eta priors
# 
# # adjust priors for beta and eta
# beta.percentages <- c(50, 60, 10, 90)
# eta.percentages  <- c(50, 60, 20, 80)
# 
# bayes.priors <- function(beta.percentages, eta.percentages){
#   # define priors for betas
#   beta.matrix <- matrix(NA, ncol = 2, nrow = 4)
#   beta.priors <- NULL
#   for(i in seq_along(beta.percentages)){
#     beta.matrix[i, ] <- c(beta.percentages[i]/10, 10-beta.percentages[i]/10)
#     beta.priors[i]   <- paste("beta[", i, "] ~ dbeta(",beta.matrix[i, 1],",",beta.matrix[i, 2],")", sep = "")
#   }
#   # define priors for etas
#   eta.matrix <- matrix(NA, ncol = 2, nrow = 4)
#   eta.priors <- NULL
#   for(i in seq_along(eta.percentages)){
#     eta.matrix[i, ] <- c(eta.percentages[i]/10, 10-eta.percentages[i]/10)
#     eta.priors[i]   <- paste("eta[", i, "] ~ dbeta(",eta.matrix[i, 1],",",eta.matrix[i, 2],")", sep = "")
#   }
#   return(list(beta.priors = beta.priors, eta.priors = eta.priors))
# }
# bayes.priors(beta.percentages, eta.percentages)








