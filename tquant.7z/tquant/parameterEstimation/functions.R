# blim(K, N.R, method = c("MD", "ML", "MDML"), R = as.binmat(N.R),
#      P.K = rep(1/nstates, nstates),
#      beta = rep(0.1, nitems), eta = rep(0.1, nitems),
#      betafix = rep(NA, nitems), etafix = rep(NA, nitems),
#      betaequal = NULL, etaequal = NULL,
#      errtype = c("both", "error", "guessing"),
#      errequal = FALSE, randinit = FALSE, incradius = 0,
#      tol = 1e-07, maxiter = 10000, zeropad = 12)

# load packages
library(pks)
library(R2jags)


K <- as.binmat(c("0000", "0110", "0101", "1110", "1011", "1101", "1111")); 
N.R         <- rep(10, 7) 
nitems      <- ncol(K)
nstates     <- nrow(K)
R           <- as.binmat(N.R)
npatterns   <- 7
n.observ    <- sum(N.R)
names(N.R)  <- as.pattern(K)
rownames(K) <- as.pattern(K)
  
## Classical parameter estimation
classic.blim <- blim(K, N.R, method = "ML")

# with dataset endm
data(endm)
K   <- endm$K
N.R <- endm$N.R
endm.blim <- blim(K, N.R, method = "ML")

## Bayesian parameter estimation
data    <- list("N.R", "n.observ", "R", "K", "nitems", "nstates", "npatterns")
myinits <- list(list(beta=rep(0.1, nitems), eta=rep(0.1, nitems), P.K=rep(1/nstates, nstates)),
                list(beta=rep(0.1, nitems), eta=rep(0.1, nitems), P.K=rep(1/nstates, nstates)))
parameters <- c("P.K", "eta", "beta")
samples <- jags(data, inits=myinits, parameters,
                model.file ="blim_model.txt", n.chains=1, n.iter=50000,
                n.burnin=10000, n.thin=2, DIC=T)
head(samples$BUGSoutput$sims.matrix)
# convergence diagnostics

# adjust priors for beta and eta
beta.percentages <- c(50, 60, 10, 90)
eta.percentages  <- c(50, 60, 20, 80)

bayes.priors <- function(beta.percentages, eta.percentages){
  # define priors for betas
  beta.matrix <- matrix(NA, ncol = 2, nrow = 4)
  beta.priors <- NULL
  for(i in seq_along(beta.percentages)){
    beta.matrix[i, ] <- c(beta.percentages[i]/10, 10-beta.percentages[i]/10)
    beta.priors[i]   <- paste("beta[", i, "] ~ dbeta(",beta.matrix[i, 1],",",beta.matrix[i, 2],")", sep = "")
  }
  # define priors for etas
  eta.matrix <- matrix(NA, ncol = 2, nrow = 4)
  eta.priors <- NULL
  for(i in seq_along(eta.percentages)){
    eta.matrix[i, ] <- c(eta.percentages[i]/10, 10-eta.percentages[i]/10)
    eta.priors[i]   <- paste("eta[", i, "] ~ dbeta(",eta.matrix[i, 1],",",eta.matrix[i, 2],")", sep = "")
  }
  return(list(beta.priors = beta.priors, eta.priors = eta.priors))
}
bayes.priors(beta.percentages, eta.percentages)








