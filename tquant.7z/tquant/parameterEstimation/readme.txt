Parameter estimation.

# What does the App do?
This app will demonstrate you parameter estimation in
probabilistic knowledge space theory. First we will cover the
most important theoretical aspects of the three estimation
procedures.
Then, you will be able to make changes on the observed response
patterns and parameters. 


With a given knowledge structure and an observed response
pattern across all responses, there are four ways to estimate
the parameters of your basic local independence Model (BLIM):

- Maximum Likelihood Estimation (ML)
- Minimum Discrepancy Method (MD)
- Minimum Discrepancy ML Estimation (MDML)
- Bayesian Parameter estimation

This app allows you to perform all four types of paramter estimation,
visualize the results and compare the different estimation methods with each other.

# Current status

- runs bayesian analysis with beta(1,1) priors for item paramters (no customisation possible)
- runs frequentist analysis
	- user can choose between ML, MD and MDML
- blots beta, eta and blim
- plots prior and posterior distribution for bayesian analysis 

# Future plans

- December:
	- include bayesian convergence diagnostics
	- user should be able to change priors 
- January:
	- The user should be able to change the observed response patterns 
- February:
	- bayesian and frequentist analysis should be comparable
- March: 
	- work on UI and plots, make App more userfriendly
	- all plots should be downloadable as .zip files
- April:
	- optimize the APP

