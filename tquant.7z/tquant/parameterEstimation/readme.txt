Parameter estimation.

# What does the App do?
This app will demonstrate you parameter estimation in
probabilistic knowledge space theory. First we will cover the
most important theoretical aspects of the three estimation
procedures.
Then, you will be able to make changes on the observed response
patterns and parameters. 


With a given knowledge structure and an observed response
pattern across all responses, there are four ways to estimate
the parameters of your basic local independence Model (BLIM):

- Maximum Likelihood Estimation (ML)
- Minimum Discrepancy Method (MD)
- Minimum Discrepancy ML Estimation (MDML)
- Bayesian Parameter estimation

This app allows you to perform all four types of paramter estimation

# Current status

- Ui, without functionalities
- R functions:
	- plot function to visualize estimated knowledge structures
        - functions to estimate the BLIM in the frequentist framework
        - functions to estimate the BLIM in the Bayesian framework

# Future plans

# until Tuesday
- Integrate the functions in the existing Ui
- The user should be able to change the observed response patterns 
- The user should be able to change the beta and eta coefficients for the
  frequentist framework and should be able to choose from ML, MD and MDML
- The user should be able to select the Bayesian parameter estimation and
  do convergence diagnostics

# until the next "release"
- The user should be able to download all plots as .zip file
- The user should be able to set the priors for the beta and eta coefficients
  in the Bayesian framework
- The paramter estimations between the frequentist and Bayesian framework
  should be comparable (e.g., in a table)

