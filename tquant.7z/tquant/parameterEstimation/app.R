

shinyApp(
  ui = tagList(
    navbarPage(
      theme = "united",  # <--- To use a theme, uncomment this
      "Probabilistic Knowledge Structures",
      tabPanel("Estimation",
               sidebarPanel(
                 tags$h4("Model specification"), br(),
                 checkboxGroupInput("init_values", "Change inital values:",
                                    choices = c("Careless errors"      = "careless",
                                                "Lucky guesses"        = "luckyguess",
                                                "Response frequencies" = "responses"),
                                    selected = "option2"
                 ),
                 selectInput("analysis", "Analysis types:",
                             choices = c("Bayesian analysis"  = "bayesian",
                                         "Classical analysis" = "classic"),
                             selected = "classic"
                 ),
                 actionButton("goButton", "Go", class = "btn-primary")
               ),
               mainPanel(
                 tabsetPanel(
                   tabPanel("Analysis",
                            h4("Table"),
                            tableOutput("table"),
                            h4("Verbatim text output"),
                            verbatimTextOutput("txtout"),
                            h1("Header 1"),
                            h2("Header 2"),
                            h3("Header 3"),
                            h4("Header 4"),
                            h5("Header 5")
                   ),
                   tabPanel("Additional information"),
                   tabPanel("See code")
                 )
               )
      ),
      tabPanel("About"),
      tabPanel("The Team")
    )
  ),
  server = function(input, output) {
    output$txtout <- renderText({
      paste(input$txt, input$slider, format(input$date), sep = ", ")
    })
    output$table <- renderTable({
      head(cars, 4)
    })
  }
)

