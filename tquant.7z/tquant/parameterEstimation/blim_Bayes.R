## clear workspace
# rm(list=ls(all=TRUE))

## Bayesian parameter estimation
library(R2jags)
library(pks)

# define new variables
 Bayes <- matrix(NA, 24, 3)
# Bayes <- matrix(NA, 23, 3)
Post  <- list(Mis = list(two = NA, five = NA, seven = NA),
              Korr=list(two=NA, five=NA, seven=NA))
n.observ <- c(200, 500, 700)

# define K
nitems  <- ncol(K)
nstates <- nrow(K)
rownames(K) <- as.pattern(K)

for(k in 1:3){
  blim.0$ntotal <- n.observ[k]
  set.seed(1)
  N.R <- simulate(blim.0)
  N.Rincomp <- N.R
  R   <- expand.grid(rep(list(0:1), nitems), KEEP.OUT.ATTRS = FALSE)
  N.R <- setNames(integer(nrow(R)), as.pattern(R))
  R   <- as.binmat(N.R)
  N.R[match(names(N.Rincomp), names(N.R))] <- N.Rincomp
  npatterns <- length(N.R)
  n.observ <- n.observ[k]

  
  data <- list("N.R", "n.observ", "R", "K", "nitems", "nstates", "npatterns")
  myinits <- list(
  list(beta=rep(0.1, nitems), eta=rep(0.1, nitems), P.K=rep(1/nstates, nstates)))
  parameters <- c("P.K", "eta", "beta")
  samples <- jags(data, inits=myinits, parameters,
              model.file ="blim_model.txt", n.chains=3, n.iter=10000,
              n.burnin=1, n.thin=2, DIC=T)
  Post$Korr[[k]]<- as.matrix(as.mcmc(samples))[,-8]
  n.observ      <- c(200, 500, 700)
}

