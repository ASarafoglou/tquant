library(shiny)
library(pks)

########## ui function ##########
ui <- fluidPage(
  titlePanel("Titel", windowTitle = "soshiny"),
  
  fluidRow(
    column(width = 3,
      # sliders for the probability of each knowledge state
      # change: probabilities instead of weights;
      # 	display error message when they don't add up to 1?

      sliderInput("P.K.1", "Select a weight for K={}", # latex code?
		  min = 1, max = 100, value = 20, step = 1),
      sliderInput("P.K.2", "Select a weight for K={b,c}",
		  min = 1, max = 100, value = 20, step = 1),
      sliderInput("P.K.3", "Select a weight for K={b,d}",
		  min = 1, max = 100, value = 20, step = 1),
      sliderInput("P.K.4", "Select a weight for K={a,b,c}",
		  min = 1, max = 100, value = 20, step = 1)
      ),
    column(width = 6,
	   plotOutput("blimplot")
      ),
	   
    column(width = 3,
      sliderInput("P.K.5", "Select a weight for K={a,b,d}",
		  min = 1, max = 100, value = 20, step = 1),
      sliderInput("P.K.6", "Select a weight for K={a,c,d}",
		  min = 1, max = 100, value = 20, step = 1),
      sliderInput("P.K.7", "Select a weight for {a,b,c,d}",
		  min = 1, max = 100, value = 20, step = 1)
      )
  )
)

########## server function ##########
server <- function(input, output){

  # convert weights to probabilities
  prob.K <- reactive({
	      weights <- c(input$P.K.2, input$P.K.4, input$P.K.1, input$P.K.6,
			   input$P.K.7, input$P.K.3, input$P.K.5)
	      # reflects order in plot function
	      
	      weights / sum(weights)
  }) # tested: seems about right

# Alex plot function
  blimplot <- function(P.K){
    
    sets <- c("bc", "abc", "acd", "abcd", "bd", "abd")
    
    # coordinates
    x0 <- c(1, 1, 4, 4, 4, 7, 7)   
    y0 <- c(4, 7, 1, 7, 10, 4, 7)-0.5
    # Plot Knowledge Structure
    # Empty Plot
    plot(1, type = "n", xlab = "", ylab = "", 
         xlim = c(0, 10),  # make dependent of size? 
         ylim = c(0, 12), 
         axes = FALSE)
    # Add Lines
    polygon(x = c(5, 2, 2, 5, 5, 5, 8, 8, 5),
            y = c(1, 4, 7, 10, 7, 1, 4, 7, 10),
            border = "grey36",
            lwd    = 2) 
    # Add Points
    symbols(x = c(2, 2, 5, 5, 5, 8, 8),
            y = c(4, 7, 1, 7, 10, 4, 7),
            circles = rep(0.6, 7),  # scales with window size
            add     = TRUE, 
            inches  = FALSE, 
            bg      = "lightgrey", 
            fg      = "grey36",
            lwd     = 2)
    # Add Knowledge States
    text(x = c(2, 2, 5, 5, 8, 8),
         y = c(4, 7, 7, 10, 4, 7),
         labels = sets,
         col    = "darkred",
         cex    = 1.5)
    text(x = 5, 
         y = 1, 
         labels = expression(symbol("\306")),  # Empty Set
         col    = "darkred", 
         cex    = 1.5)
    # Barplots for P.K values
    for(i in 1:7){
        rect(x0[i] + 0.1, y0[i], x0[i] + 0.3, y0[i] + (P.K[i] * 4),
             col    = "red3", 
             border = "grey36")
    }
    # Add Axis of Barplots
    segments(x0 = x0, y0 = y0, x1 = x0, y1 = y0 + 0.8)             # Axis 
    segments(x0 = x0, y0 = y0, x1 = x0 - 0.1, y1 = y0)             # Ticks
    segments(x0 = x0, y0 = y0 + 0.8, x1 = x0 - 0.1, y1 = y0 + 0.8)
    segments(x0 = x0, y0 = y0 + 0.4, x1 = x0 - 0.1, y1 = y0 + 0.4)
    text(x0, y0, pos = 2, labels = rep("0", 8))                    # Labels
    text(x0, y0 + 0.8, pos = 2, labels = rep(".2", 8))
  }

  output$blimplot <- renderPlot({
	  blimplot(P.K = prob.K())
  })

}

shinyApp(ui = ui, server = server)

# To Do
#  - all hard coded -> resizing of the window can lead to the circles stretching
#    past the graphics window or overlapping -> somehow make it dependent on
#    window size???
#
#  - probabilities instead of weights?
