Predictions of a probabilistic knowledge structure.

