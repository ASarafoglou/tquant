Contributers: Kathi

Identifiability.

The app visualises the parameter trade-off of two parameters leading to the
same outcome. The trade-off is shown using the three-item-example of the pksII
slides. The parameters involved in the trade-off are beta_c and pi_ab.

Two helper functions are used to plot the vector field: expand.outer and
plotVectorField.

