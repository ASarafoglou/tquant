library(shiny)

source("helpers.R")

shinyServer(function(input, output) {

  output$ui_slider_beta_c <- renderUI({
    pi.ab <- ifelse(is.null(input$pi_ab), .54, input$pi_ab)
    beta.c.0 <- input$beta_c_0
    beta.c.start <- (-pi.ab + pi.ab.0 + beta.c.0 * (1 - pi.empty - pi.ab.0)) /
                    (-pi.ab - pi.empty + 1)
    sliderInput("beta_c", label="", min=0, max=beta.c.0,
                value=beta.c.start, step=.01, animate=animationOptions(200))
  })

  output$ui_slider_pi_ab <- renderUI({
    beta.c <- ifelse(is.null(input$beta_c), .05, input$beta_c)
    beta.c.0 <- input$beta_c_0
    beta.c <- input$beta_c
    max <- round(beta.c.0 * (1 - pi.empty) + (1 - beta.c.0) * pi.ab.0,
                 digits=3)
    pi.ab.start <- ((beta.c.0 - beta.c) * (1 - pi.empty) + (1 - beta.c.0) *
                    pi.ab.0) / (1 - beta.c)
    sliderInput("pi_ab", label="", min=0, max=max, step=.01,
                value=pi.ab.start)
  })

  # set parameters for plotting indifference curve
  pi.empty <- 0.4
  ngp <- c(10, 10)
  xoffset <- 0.05
  yoffset <- 0.05 * (1 - pi.empty)
  pi.ab.0 <- 0
  xstep <- (1 - 2 * xoffset) / (ngp[1] - 1)

  output$plot <- renderPlot({
    par(cex.lab=1.2, mar=c(4.1, 4.0, 0, 0), pty="s")
    plotVectorField(
                    vecfun = function(x1, x2) {
                      c(-(1 - x1) / (1 - pi.empty - x2), 1 + 0 * x2)
                    },
                    xlim = c(0 + xoffset, 1 - xoffset),
                    ylim = c(0 + yoffset, 1 - pi.empty - yoffset),
                    grid.points = ngp
                    )
    axis(1, seq(0.0, 1.0, 0.1))
    axis(2, seq(0.0, 1 - pi.empty, 0.1))
    # insert curves into plot
    beta.c.0 <- input$beta_c_0
      curve(((beta.c.0 - x) * (1 - pi.empty) + (1 - beta.c.0) * pi.ab.0) /
            (1 - x), xlim=c(0, (pi.ab.0 + beta.c.0 * (1 - pi.empty - pi.ab.0))
                            / (1 - pi.empty)), col="blue", add=TRUE)

    # Draw point
    if (input$tabs == "beta_c") {
        beta.c <- input$beta_c
        points(beta.c, ((beta.c.0 - beta.c) * (1 - pi.empty) + (1 - beta.c.0) *
                        pi.ab.0) / (1 - beta.c), pch=16, col="black")
    } else if (input$tabs == "pi_ab") {
        pi.ab <- ifelse(is.null(input$pi_ab), .54, input$pi_ab)
        points((-pi.ab + pi.ab.0 + beta.c.0 * (1 - pi.empty - pi.ab.0)) /
               (-pi.ab - pi.empty + 1), pi.ab, pch=16, col="black")
    }
  })

  # set parameters for predictions
  beta.a <- .3
  beta.b <- .3

  output$predictions_plot <- renderPlot({
    beta.c.0 <- input$beta_c_0
    if (input$tabs == "beta_c") {
        beta.c <- ifelse(is.null(input$beta_c), .05, input$beta_c)
        pi.ab <- ((beta.c.0 - beta.c) * (1 - pi.empty) + (1 - beta.c.0) *
                 pi.ab.0) / (1 - beta.c)
    } else if (input$tabs == "pi_ab") {
        pi.ab <- ifelse(is.null(input$pi_ab), .54, input$pi_ab)
        beta.c <- (-pi.ab + pi.ab.0 + beta.c.0 * (1 - pi.empty - pi.ab.0)) /
                  (-pi.ab - pi.empty + 1)
   }

    pred <- predictionFunction(beta.a, beta.b, beta.c, pi.empty, pi.ab)
    pred <- c(pred, phi.abc = 1 - sum(pred)) * 100
    barplot(pred,
            horiz = TRUE,
            names.arg = c("0", "a", "b", "c", "ab", "ac", "bc", "abc"),
            cex.names = 1.3,
            las = 2,
            axes = FALSE,
            col = "lightblue",
            xlim = c(0, max(pred)),
            border = NA
            )
    axis(side = 3, cex.axis = 1.3)
  })

})
