library(shiny)

shinyUI(fluidPage(
  titlePanel("Identifiability of a Knowledge Structure"),
  withMathJax(),

  p("This Shiny App visualizes the trade-off for parameters of a non-identifiable
    knowledge structure. The example displayed directly refers to the
    presentation 'Probabilistic Knowledge Structures II' by Heller and
    Wickelmaier, slides 19 to 22."),
  p("The item set consists of three items, \\(Q = \\{a, b, c\\}\\), and the
    knowledge structure is \\(\\mathcal{K}^{02} = \\{\\emptyset, \\{a, b\\},
    Q\\}\\). The parameter vector is \\(\\theta' = (\\beta_a, \\beta_b,
    \\beta_c, \\pi_\\emptyset, \\pi_{ab})\\), not allowing for guessing."),

  h3("Trade-off of parameters \\(\\beta_c\\) and \\(\\pi_{ab}\\)"),
  fluidRow(
    column(3,
          h5("Choose indifference curve"),
          sliderInput("beta_c_0", label="",
                      min=0, max=.99, value=.9, step=.05),
          h5("Variate parameter"),
          tabsetPanel(id="tabs",
                      tabPanel(title=HTML("$$\\beta_c$$"),
                               value="beta_c",
                               uiOutput("ui_slider_beta_c")
                      ),
                      tabPanel(title=HTML("$$\\pi_{ab}$$"),
                               value="pi_ab",
                               uiOutput("ui_slider_pi_ab")
                      ))
    ),
    column(4,
          plotOutput("plot")
    ),
    column(4,
           h5("Predicted responses (N = 100)"),
           plotOutput("predictions_plot")
    )
  )
))
